var colorDictionary = { 
    1: "green",
    2: "red",
    3: "yellow",
    4: "blue"
};

var gameArray = [];
var gameIndex = 0;
var startGame = 0;

function buttonSound(colour)
{
    switch(colour)
    {
        case "green":
            var audio = new Audio("sounds/green.mp3");
            audio.play();
            break; 

        case "yellow":
            var audio = new Audio("sounds/yellow.mp3");
            audio.play();
            break; 
        
        case "red":
            var audio = new Audio("sounds/red.mp3");
            audio.play();
            break; 

        case "blue":
            var audio = new Audio("sounds/blue.mp3");
            audio.play();
            break; 
    }
}

function buttonAnimation(colour)
{
    var buttonPressed = $("."+colour);
    buttonPressed.addClass("pressed");
    setTimeout(function(){ 
        buttonPressed.removeClass("pressed"); 
    }, 100);
}


function wrongSound()
{
    var audio = new Audio("sounds/wrong.mp3");
    audio.play();
}

function wrongAnimation(colour)
{
    document.querySelector("body").style.backgroundColor = "red";
    var buttonPressed = $("."+colour);
    buttonPressed.addClass("game-over");
    setTimeout(function(){ 
        buttonPressed.removeClass("game-over"); 
        document.querySelector("body").style.backgroundColor = "#011F3F";
    }, 100);
}

function gameOn()
{
    var level = 1;
    gameArray = [];
    gameIndex = 0;
    while(true)
    {
        document.querySelector("h1").innerHTML = "Level " + level;
        var newNumber = Math.floor(4*Math.random()) + 1;
        var colour = colorDictionary[newNumber];
        gameArray.push(colour);
        buttonSound(colour);
        buttonAnimation(colour);

        while(gameIndex < gameArray.length && startGame == 1)
        {
            setTimeout(function(){}, 5000);
        }
        if(gameIndex == gameArray.length)
        {
            level += 1;
        }
        else if(startGame == 0)
        {
            break;
        }
    }
}

var numberOfButtons = document.querySelectorAll("button").length;

for (var i = 0 ; i< numberOfButtons; i++)
{
    var currentButton = document.querySelectorAll("button")[i];
    currentButton.addEventListener("click", function(){
        var colour = this.id;
        if(gameArray.length == 0)
        {
            buttonSound(colour);
            buttonAnimation(colour);
        }
        else if(gameIndex < gameArray.length && color == gameArray[gameIndex])
        {
            buttonSound(colour);
            buttonAnimation(colour);
            gameIndex += 1;
        }
        else 
        {
            wrongSound();
            wrongAnimation(color);
            document.querySelector("h1").innerHTML = "Game over, Press Any Key to Restart";
            startGame = 0;
            gameIndex = 0;
        }
    });
}

document.addEventListener("keydown", function(){
    if(startGame == 0)
    {
        startGame = 1;
        gameOn();
    }
});
